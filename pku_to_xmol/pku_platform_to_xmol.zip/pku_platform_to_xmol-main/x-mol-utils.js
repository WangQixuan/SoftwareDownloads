// 使用现代JavaScript语法优化版本
let loadingIndicator; // 全局加载指示器引用

// Chrome存储操作Promise封装
const chromeStorageGet = (key) => {
    if (typeof chrome === 'undefined' || !chrome.storage?.local) {
        console.warn('无法访问Chrome存储API');
        return Promise.resolve(null);
    }
    
    return new Promise((resolve, reject) => {
        chrome.storage.local.get(key, (result) => {
            if (chrome.runtime.lastError) {
                reject(new Error(`获取存储数据失败: ${chrome.runtime.lastError.message}`));
            } else {
                resolve(result[key]);
            }
        });
    });
};

const chromeStorageRemove = (key) => {
    if (typeof chrome === 'undefined' || !chrome.storage?.local) {
        console.warn('无法访问Chrome存储API');
        return Promise.resolve();
    }
    
    return new Promise((resolve) => {
        chrome.storage.local.remove(key, () => {
            if (chrome.runtime.lastError) {
                console.error(`清除存储数据失败: ${chrome.runtime.lastError.message}`);
            }
            resolve();
        });
    });
};

// 显示加载指示器
const showLoadingIndicator = () => {
    // 移除已存在的指示器
    hideLoadingIndicator();
    
    // 创建加载指示器元素
    loadingIndicator = document.createElement('div');
    loadingIndicator.style.cssText = `
        position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%);
        background-color: rgba(255,255,255,0.95); padding: 20px 30px; border-radius: 5px;
        box-shadow: 0 2px 10px rgba(0,0,0,0.2); z-index: 9999; display: flex; align-items: center;
        gap: 10px; font-size: 14px; color: #333;
    `;
    
    // 添加加载图标
    const spinner = document.createElement('div');
    spinner.style.cssText = `
        width: 16px; height: 16px; border: 2px solid #f3f3f3;
        border-top: 2px solid #3498db; border-radius: 50%;
        animation: spin 1s linear infinite;
    `;
    
    // 添加CSS动画（只添加一次）
    if (!document.getElementById('xmol-spinner-animation')) {
        const style = document.createElement('style');
        style.id = 'xmol-spinner-animation';
        style.textContent = '@keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }';
        document.head.appendChild(style);
    }
    
    // 组装并添加到页面
    loadingIndicator.appendChild(spinner);
    loadingIndicator.appendChild(document.createTextNode('正在自动填充试剂信息...'));
    document.body.appendChild(loadingIndicator);
};

// 隐藏加载指示器
const hideLoadingIndicator = () => {
    if (loadingIndicator?.parentNode) {
        loadingIndicator.remove();
        loadingIndicator = null;
    }
};

// DOM元素查找函数
const findElement = (selectors, context = document) => {
    const selectorArray = Array.isArray(selectors) ? selectors : [selectors];
    for (const selector of selectorArray) {
        const element = context.querySelector(selector);
        if (element) return element;
    }
    return null;
};

// 填充表单字段函数
const fillFormField = (name, value) => {
    // 为每个字段提供多个备选选择器
    const selectors = [
        `input[name="${name}"]`,
        `#${name}`,
        `.${name}`,
        `input[id="${name}"]`
    ];
    const input = findElement(selectors);
    
    if (input && value && value.trim() !== '') {
        // 仅在值不同时更新
        if (input.value !== value) {
            input.value = value;
            
            // 触发必要的事件
            try {
                input.dispatchEvent(new Event('input', { bubbles: true }));
                input.dispatchEvent(new Event('change', { bubbles: true }));
            } catch {
                // 降级方案
                if (input.oninput) input.oninput();
                if (input.onchange) input.onchange();
            }
        }
    }
};

const handlePageLoad = async () => {
    try {
        // 显示加载指示器
        showLoadingIndicator();
        
        // 获取并清除试剂信息
        const reagentInfo = await chromeStorageGet('reagent_info');
        await chromeStorageRemove('reagent_info');
        
        // 检查是否有试剂信息
        if (!reagentInfo) {
            console.log('没有找到需要导入的试剂信息');
            hideLoadingIndicator();
            return;
        }
        
        // 查找并点击添加按钮
        let addButton = document.querySelector('#ivSearchForm > div > div.col-md-5 > a:nth-child(1)');
        
        if (!addButton) {
            // 尝试备选选择器
            addButton = findElement([
                'a[data-toggle="modal"].btn.btn-primary.btn-sm[onclick*="addIv"]',
                '#ivSearchForm > div > div.col-md-5 > a:first-child'
            ]);
            
            if (!addButton) {
                console.error('未能找到添加按钮，可能是页面结构已更改');
                hideLoadingIndicator();
                alert('未能找到添加按钮，请检查X-MOL页面结构是否已更改。');
                return;
            }
        }
        
        // 点击添加按钮
        addButton.click();
        
        // 开始轮询表单元素
        let pollCount = 0;
        const maxAttempts = 35; // 总等待时间约7秒
        const intervalMs = 200;
        
        const pollingInterval = setInterval(() => {
            pollCount++;
            
            // 检查CAS输入框是否存在
            const casInput = document.querySelector('input[name="cas"]');
            
            if (casInput) {
                clearInterval(pollingInterval);
                
                // 添加插件信息
                const modalBody = document.querySelector('#ivAddForm .modal-body');
                if (modalBody) {
                    const infoDiv = document.createElement('div');
                    infoDiv.innerHTML = '此页面信息导入由pku_platform_to_xmol插件提供，作者：<a target="_blank" href="https://www.wangqixuan.cn/pages/about.html">王琪璇</a>';
                    modalBody.appendChild(infoDiv);
                }
                
                // 定义表单字段映射
                const fieldMappings = {
                    cas: 'casno',
                    brand: '品牌',
                    supplier: '供货商名称',
                    purity: '纯度',
                    specificationUnit: '包装规格',
                    category: '产品分类',
                    code: '货号',
                    price: '单价'
                };
                
                // 填充基本字段
                Object.entries(fieldMappings).forEach(([field, key]) => {
                    const input = document.querySelector(`input[name="${field}"]`);
                    if (input) input.value = reagentInfo[key] || '';
                });
                
                // 延迟填充名称字段
                setTimeout(() => {
                    const nameZhInput = document.querySelector('input[name="nameZh"]');
                    const nameEnInput = document.querySelector('input[name="nameEn"]');
                    
                    if (nameZhInput) nameZhInput.value = reagentInfo['中文品名'] || '';
                    if (nameEnInput) nameEnInput.value = reagentInfo['英文品名'] || '';
                    
                    // 触发事件以确保表单验证正常
                    [casInput, nameZhInput, nameEnInput].forEach(input => {
                        if (input) {
                            try {
                                input.dispatchEvent(new Event('input', { bubbles: true }));
                                input.dispatchEvent(new Event('change', { bubbles: true }));
                            } catch {}
                        }
                    });
                    
                    // 完成后隐藏加载指示器
                    setTimeout(hideLoadingIndicator, 300);
                }, 300);
                
            } else if (pollCount > maxAttempts) {
                clearInterval(pollingInterval);
                console.error(`经过${maxAttempts}次尝试(约${Math.round(maxAttempts * intervalMs / 1000)}秒)后未能找到表单元素`);
                hideLoadingIndicator();
                alert('无法找到表单元素，请手动填充试剂信息。');
            }
        }, intervalMs);
        
    } catch (error) {
        console.error('自动填充过程中发生错误:', error);
        hideLoadingIndicator();
        
        // 错误处理
        if (confirm(`自动填充失败: ${error.message || '未知错误'}\n\n是否重试自动填充？`)) {
            setTimeout(handlePageLoad, 500);
        }
    }
};

// 保存原始onload函数
const originalOnload = window.onload;

// 设置页面加载事件处理
window.onload = function() {
    if (originalOnload) originalOnload();
    handlePageLoad();
};


