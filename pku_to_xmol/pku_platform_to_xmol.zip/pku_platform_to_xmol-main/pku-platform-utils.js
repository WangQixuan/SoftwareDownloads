// DOM元素查找函数，支持多个备选选择器
const findElement = (selectors) => {
    const selectorArray = Array.isArray(selectors) ? selectors : [selectors];
    for (const selector of selectorArray) {
        const element = document.querySelector(selector);
        if (element) return element;
    }
    return null;
};

// Chrome存储操作Promise封装
const chromeStorageSet = (data) => {
    if (typeof chrome === 'undefined' || !chrome.storage?.local) {
        return Promise.reject(new Error('无法访问Chrome扩展API'));
    }
    
    return new Promise((resolve, reject) => {
        chrome.storage.local.set(data, () => {
            if (chrome.runtime.lastError) {
                reject(new Error(`存储失败: ${chrome.runtime.lastError.message}`));
            } else {
                resolve();
            }
        });
    });
};

const loadPlugin = () => {
    const productIdMatch = location.hash.match(/#\/product\/detail\?id=(\d*)/);
    if (!productIdMatch) return;
    
    const productId = productIdMatch[1];
    let pollCount = 0;
    const maxPollAttempts = 8;
    const containerSelectors = ['div.info', '.product-info', '#product-detail-info', '.detail-container'];
    
    // 使用箭头函数避免闭包问题
    const pollingInterval = setInterval(() => {
        pollCount++;
        
        if (pollCount > maxPollAttempts) {
            console.warn('未能找到信息容器，无法添加一键入库按钮');
            clearInterval(pollingInterval);
            return;
        }
        
        const infoContainer = findElement(containerSelectors);
        if (infoContainer) {
            clearInterval(pollingInterval);
            
            // 创建并配置按钮
            const button = document.createElement('button');
            button.type = 'button';
            button.className = 'el-button el-button--primary';
            button.textContent = '一键入库';
            button.dataset.productId = productId;
            button.style.marginTop = '10px';
            
            button.addEventListener('click', function() {
                this.disabled = true;
                this.textContent = '正在处理...';
                submitInfo(productId, this);
            });
            
            infoContainer.appendChild(button);
            
            // 自动提交模式
            if (location.hash.includes('in_storage=1')) {
                setTimeout(() => submitInfo(productId), 500);
            }
        }
    }, 400);
};

// 提交信息函数
const submitInfo = async (productId, buttonElement = null) => {
    try {
        // 检查Chrome扩展API是否可用
        if (typeof chrome === 'undefined' || !chrome.storage) {
            handleApiUnavailable(productId);
            return;
        }
        
        // 设置请求超时
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 8000);
        
        // 构建并发送请求
        const formData = new URLSearchParams({
            query: 'jk产品详情',
            '产品id': productId
        });
        
        const response = await fetch('https://reagent.pku.edu.cn/Jpost', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: formData,
            signal: controller.signal
        });
        
        clearTimeout(timeoutId);
        
        if (!response.ok) {
            throw new Error(`HTTP错误! 状态码: ${response.status}`);
        }
        
        // 解析响应数据
        const data = await response.text();
        const parsedData = JSON.parse(data);
        
        if (!parsedData.data?.[0]) {
            throw new Error('获取的试剂数据格式不正确');
        }
        
        // 存储数据
        await chromeStorageSet({ reagent_info: parsedData.data[0] });
        
        // 打开新窗口
        if (!window.open('https://www.x-mol.com/group/iv/index', '_blank')) {
            alert('无法打开x-mol入库页面，请手动打开并添加信息。');
        }
        
        // 自动模式窗口关闭
        if (location.hash.includes('in_storage=1')) {
            setTimeout(() => window.close(), 1000);
        }
        
    } catch (error) {
        console.error('一键入库操作失败:', error);
        
        // 简化错误处理
        if (error.name === 'AbortError') {
            alert('操作失败: 请求超时，请检查网络连接');
        } else if (error.message?.includes('Chrome扩展API')) {
            handleApiUnavailable(productId);
            return;
        } else {
            alert(`操作失败${error.message ? ': ' + error.message : ''}`);
        }
    } finally {
        // 恢复按钮状态
        if (buttonElement && document.contains(buttonElement)) {
            setTimeout(() => {
                buttonElement.disabled = false;
                buttonElement.textContent = '一键入库';
            }, 1500);
        }
    }
};

// 当Chrome扩展API不可用时的处理函数
const handleApiUnavailable = (productId) => {
    // 创建错误提示容器
    const errorContainer = document.createElement('div');
    errorContainer.className = 'extension-error-container';
    errorContainer.style.cssText = `
        position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%);
        background-color: #fff; border: 1px solid #ddd; border-radius: 8px; padding: 20px;
        width: 320px; max-width: 90%; box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        z-index: 9999; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    `;
    
    errorContainer.innerHTML = `
        <h3 style="margin-top: 0; color: #e74c3c; font-size: 18px;">插件操作提示</h3>
        <p style="line-height: 1.6; color: #333;">无法访问Chrome扩展API，您可以通过以下方式手动操作：</p>
        <ol style="line-height: 1.6; padding-left: 20px;">
            <li>复制当前页面的试剂信息</li>
            <li>手动打开X-MOL入库页面</li>
            <li>粘贴试剂信息并保存</li>
        </ol>
        <button id="copyInfoBtn" style="
            background-color: #3498db; color: white; border: none; padding: 8px 16px;
            border-radius: 4px; cursor: pointer; margin-right: 10px; margin-top: 10px;
        ">复制产品ID</button>
        <button id="closeBtn" style="
            background-color: #ecf0f1; color: #2c3e50; border: none; padding: 8px 16px;
            border-radius: 4px; cursor: pointer; margin-top: 10px;
        ">关闭</button>
    `;
    
    document.body.appendChild(errorContainer);
    
    // 复制按钮事件
    const copyBtn = errorContainer.querySelector('#copyInfoBtn');
    const closeBtn = errorContainer.querySelector('#closeBtn');
    
    copyBtn.onclick = async () => {
        try {
            await navigator.clipboard.writeText(productId);
            alert('产品ID已复制到剪贴板');
        } catch {
            alert('复制失败，请手动复制: ' + productId);
        }
    };
    
    // 关闭按钮和点击外部关闭事件
    const removeContainer = () => errorContainer.remove();
    closeBtn.onclick = removeContainer;
    errorContainer.addEventListener('click', (e) => e.target === errorContainer && removeContainer());
};

// 初始化逻辑
const initPlugin = () => {
    if (location.hash.match(/#\/product\/detail\?id=(\d*)/)) {
        loadPlugin();
    }
};

// 简化的页面加载事件处理
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initPlugin);
} else {
    initPlugin();
}

// URL变更监听，用于SPA页面切换
window.addEventListener('hashchange', initPlugin);


