# PKU Platform to X-MOL 插件

## 简介

这是一个Chrome浏览器扩展，用于在北大试剂平台和X-MOL数据库之间自动传输试剂信息，简化实验人员的工作流程，提高数据录入效率。

This Chrome extension allows for seamless transfer of reagent data from Peking University's reagent platform to X-MOL database, simplifying workflow and improving data entry efficiency for laboratory personnel.

## 功能特点

- 自动检测北大试剂平台的试剂详情页
- 添加便捷的"一键入库"按钮到试剂详情页
- 将试剂信息自动存储并填充到X-MOL入库页面
- 简洁高效的用户界面，无需复杂配置
- 可靠的错误处理机制

## 安装说明

1. 下载并解压本扩展包
2. 在Chrome浏览器中，打开扩展管理页面（输入 `chrome://extensions/` 到地址栏）
3. 开启右上角的"开发者模式"
4. 点击"加载已解压的扩展程序"按钮，选择解压后的文件夹
5. 扩展程序安装成功后，会在Chrome浏览器工具栏显示

## 使用方法

1. 确保已登录X-MOL账户并能够访问库存管理页面
2. 访问北大试剂管理平台（pku-chem-ivt.pku.edu.cn）
3. 进入试剂详细信息页面
4. 页面上会自动出现"一键入库"按钮
5. 点击按钮，系统会自动处理并打开X-MOL入库页面
6. 所有试剂信息已自动填充，您只需确认信息并输入库存位置即可

## 注意事项

- 本插件仅适用于北大试剂管理平台和X-MOL数据库
- 使用前请确保已正确登录X-MOL账户
- 如果"一键入库"按钮未出现，请刷新页面重试
- 如需支持新功能或报告问题，请联系开发者

## 更新日志

### v1.0
- 初始版本发布
- 实现北大试剂平台到X-MOL的数据自动传输功能
- 优化用户界面和操作流程



